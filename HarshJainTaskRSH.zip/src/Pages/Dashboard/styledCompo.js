import styled from "styled-components";

export const DivCard = styled.div`
backgroundColor: white,
color: black
`