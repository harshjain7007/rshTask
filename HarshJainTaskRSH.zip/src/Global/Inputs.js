import React from 'react'
import "./style.css"
import { useForm } from "react-hook-form";


export const TextInput = ({ name, value, onChange }) => {

  return (
    <div>

    </div>
  )
}