import SortByAlphaIcon from "@mui/icons-material/SortByAlpha";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
export const SORT_APHAPHET_ICON = () => <SortByAlphaIcon />;
export const FILTER_ICON = () => <FilterAltIcon />;
