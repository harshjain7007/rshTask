import { TableRow, TableCell } from "@mui/material"
import "./style.css"


export const TableTxt = () =>  <div className="noData" > Data not found </div> 


export const NoFoundTxt = () =>  <div className="noData" > Data not found </div> 

{/* <div className='Center_Div'></div> */}